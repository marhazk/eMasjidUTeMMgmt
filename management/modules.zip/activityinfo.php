<?php
if ($_POST["chk"] == "Save")
{
	echo "<P>The details have been saved.</P>";
}
elseif ($_POST["chk"] == "Add")
{
	echo "<P>The activity has been registered.</P>";
}
?>

<form name="form1" method="post" action="?op=activityjoin">
  <table width="100%%" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="40%"><strong>ACTIVITIY DETAIL</strong></td>
      <td width="2%">&nbsp;</td>
      <td width="58%"><a href="?op=activityedit"><img src="btn/edit.png" width="23" height="24"></a></td>
    </tr>
    <tr>
      <td width="40%">Name</td>
      <td width="2%">:</td>
      <td width="58%">ACTIVITI 1</td>
    </tr>
    <tr>
      <td width="40%">Contact Number</td>
      <td width="2%">&nbsp;</td>
      <td width="58%">012345</td>
    </tr>
    <tr>
      <td width="40%">Location</td>
      <td width="2%">:</td>
      <td width="58%">DEWAN BESAR UTEM</td>
    </tr>
    <tr>
      <td width="40%">Start Date</td>
      <td width="2%">:</td>
      <td width="58%">20 OCT 2012</td>
    </tr>
    <tr>
      <td width="40%">End Date</td>
      <td width="2%">:</td>
      <td width="58%">21 OCT 2012</td>
    </tr>
    <tr>
      <td width="40%">Organiser</td>
      <td width="2%">:</td>
      <td width="58%">HEPA UTEM</td>
    </tr>
    <tr>
      <td width="40%">Details</td>
      <td width="2%">&nbsp;</td>
      <td width="58%">&nbsp;</td>
    </tr>
    <tr>
      <td height="500" colspan="3" valign="top"><img src="poster/activity1.jpg" width="800" height="320"></td>
    </tr>
    <tr>
      <td width="40%">&nbsp;</td>
      <td width="2%">&nbsp;</td>
      <td width="58%">&nbsp;</td>
    </tr>
    <tr>
      <td width="40%">If you are interested, please fill in the blank below:</td>
      <td width="2%">&nbsp;</td>
      <td width="58%">&nbsp;</td>
    </tr>
    <tr>
      <td width="40%"><strong>For UTeM Staff or Student</strong></td>
      <td width="2%">&nbsp;</td>
      <td width="58%">&nbsp;</td>
    </tr>
    <tr>
      <td width="40%">Staff or Matrix ID</td>
      <td width="2%">:</td>
      <td width="58%"><p>
          <input name="textfield" type="text" id="textfield" size="50">
      </p>
      <p>        (eg: ABU BAKAR)</p></td>
    </tr>
    <tr>
      <td width="40%">Contact Number</td>
      <td width="2%">:</td>
      <td width="58%"><p>
          <input name="textfield2" type="text" id="textfield2" size="50">
      </p>
      <p>        (eg: LELA)</p></td>
    </tr>
    <tr>
      <td width="40%">&nbsp;</td>
      <td width="2%">&nbsp;</td>
      <td width="58%">&nbsp;</td>
    </tr>
    <tr>
      <td width="40%"><strong>For Non-UTeM</strong></td>
      <td width="2%">&nbsp;</td>
      <td width="58%">&nbsp;</td>
    </tr>
    <tr>
      <td>First Name</td>
      <td>:</td>
      <td><input name="textfield8" type="text" id="textfield9" size="50"></td>
    </tr>
    <tr>
      <td width="40%">Last Name</td>
      <td width="2%">:</td>
      <td width="58%"><input name="textfield3" type="text" id="textfield3" size="50"></td>
    </tr>
    <tr>
      <td width="40%">Identification Card Number </td>
      <td width="2%">:</td>
      <td width="58%"><p>
          <input name="textfield4" type="text" id="textfield4" size="50">
      </p>
      <p>        (eg: 811234-12-3456)</p></td>
    </tr>
    <tr>
      <td width="40%">Nationality</td>
      <td width="2%">:</td>
      <td width="58%"><p>
          <input name="textfield5" type="text" id="textfield5" size="50">
      </p>
      <p>        (eg: MALAYSIA)</p></td>
    </tr>
    <tr>
      <td width="40%">Age</td>
      <td width="2%">:</td>
      <td width="58%"><input name="textfield6" type="text" id="textfield6" size="50"></td>
    </tr>
    <tr>
      <td width="40%">Contact Number</td>
      <td width="2%">:</td>
      <td width="58%"><input name="textfield7" type="text" id="textfield7" size="50"></td>
    </tr>
    <tr>
      <td width="40%">E-Mail Address</td>
      <td width="2%">:</td>
      <td width="58%"><input name="textfield8" type="text" id="textfield8" size="50"></td>
    </tr>
    <tr>
      <td width="40%">&nbsp;</td>
      <td width="2%">&nbsp;</td>
      <td width="58%">&nbsp;</td>
    </tr>
    <tr>
      <td width="40%">&nbsp;</td>
      <td width="2%">&nbsp;</td>
      <td width="58%"><input type="submit" name="button" id="button" value="Register" />
      <input type="submit" name="button2" id="button2" value="Back" /></td>
    </tr>
    <tr>
      <td width="40%">&nbsp;</td>
      <td width="2%">&nbsp;</td>
      <td width="58%">&nbsp;</td>
    </tr>
  </table>
</form>
