<form name="form1" method="post" enctype="multipart/form-data"  action="?op=activityinfo">
  <table width="100%%" border="0" cellspacing="0" cellpadding="0">
    <tr>
      <td width="40%"><strong>ACTIVITIY DETAIL</strong></td>
      <td width="2%">&nbsp;</td>
      <td width="58%">&nbsp;</td>
    </tr>
    <tr>
      <td width="40%">Name</td>
      <td width="2%">:</td>
      <td width="58%"><input name="ename" type="text" id="ename" size="50" /></td>
    </tr>
    <tr>
      <td width="40%">Contact Number</td>
      <td width="2%">&nbsp;</td>
      <td width="58%"><input name="econtact" type="text" id="econtact" size="50" /></td>
    </tr>
    <tr>
      <td width="40%">Location</td>
      <td width="2%">:</td>
      <td width="58%"><input name="elocation" type="text" id="elocation" value="Masjid UTeM" size="50" /></td>
    </tr>
    <tr>
      <td width="40%">Start Date</td>
      <td width="2%">:</td>
      <td width="58%">Date : 
        <select name="d1" id="d1">
        <option value="" selected="selected">-</option>
        <option>1</option>
        <option>2</option>
        <option>3</option>
        <option>4</option>
        <option>5</option>
        <option>6</option>
        <option>7</option>
        <option>8</option>
        <option>9</option>
        <option>10</option>
        <option>11</option>
        <option>12</option>
        <option>13</option>
        <option>14</option>
        <option>15</option>
        <option>16</option>
        <option>17</option>
        <option>18</option>
        <option>19</option>
        <option>20</option>
        <option>21</option>
        <option>22</option>
        <option>23</option>
        <option>24</option>
        <option>25</option>
        <option>26</option>
        <option>27</option>
        <option>28</option>
        <option>29</option>
        <option>30</option>
        <option>31</option>
      </select>
/
<select name="m1" id="m1">
  <option value="" selected="selected">-</option>
  <option>1</option>
  <option>2</option>
  <option>3</option>
  <option>4</option>
  <option>5</option>
  <option>6</option>
  <option>7</option>
  <option>8</option>
  <option>9</option>
  <option>10</option>
  <option>11</option>
  <option>12</option>
</select>
/
<select name="y1" id="y1">
  <option value="" selected="selected">-</option>
  <option>2010</option>
  <option>2011</option>
  <option>2012</option>
  <option>2013</option>
  <option>2014</option>
  <option>2015</option>
  <option>2016</option>
  <option>2017</option>
</select>
Time:
<select name="ehh1" id="ehh1">
  <option value="" selected="selected">-</option>
  <option>00</option>
  <option>01</option>
  <option>02</option>
  <option>03</option>
  <option>04</option>
  <option>05</option>
  <option>06</option>
  <option>07</option>
  <option>08</option>
  <option>09</option>
  <option>10</option>
  <option>11</option>
  <option>12</option>
  <option>13</option>
  <option>14</option>
  <option>15</option>
  <option>16</option>
  <option>17</option>
  <option>18</option>
  <option>19</option>
  <option>20</option>
  <option>21</option>
  <option>22</option>
  <option>23</option>
</select> 
: 
<select name="emm1" id="emm1">
  <option value="" selected="selected">-</option>
  <option>00</option>
  <option>01</option>
  <option>02</option>
  <option>03</option>
  <option>04</option>
  <option>05</option>
  <option>06</option>
  <option>07</option>
  <option>08</option>
  <option>09</option>
  <option>10</option>
  <option>11</option>
  <option>12</option>
  <option>13</option>
  <option>14</option>
  <option>15</option>
  <option>16</option>
  <option>17</option>
  <option>18</option>
  <option>19</option>
  <option>20</option>
  <option>21</option>
  <option>22</option>
  <option>23</option>
  <option>24</option>
  <option>25</option>
  <option>26</option>
  <option>27</option>
  <option>28</option>
  <option>29</option>
  <option>30</option>
  <option>31</option>
  <option>32</option>
  <option>33</option>
  <option>34</option>
  <option>35</option>
  <option>36</option>
  <option>37</option>
  <option>38</option>
  <option>39</option>
  <option>40</option>
  <option>41</option>
  <option>42</option>
  <option>43</option>
  <option>44</option>
  <option>45</option>
  <option>46</option>
  <option>47</option>
  <option>48</option>
  <option>49</option>
  <option>50</option>
  <option>51</option>
  <option>52</option>
  <option>53</option>
  <option>54</option>
  <option>55</option>
  <option>56</option>
  <option>57</option>
  <option>58</option>
  <option>59</option>
</select></td>
    </tr>
    <tr>
      <td width="40%">End Date</td>
      <td width="2%">:</td>
      <td width="58%">Date : 
        <select name="ed2" id="ed2">
        <option value="" selected="selected">-</option>
        <option>1</option>
        <option>2</option>
        <option>3</option>
        <option>4</option>
        <option>5</option>
        <option>6</option>
        <option>7</option>
        <option>8</option>
        <option>9</option>
        <option>10</option>
        <option>11</option>
        <option>12</option>
        <option>13</option>
        <option>14</option>
        <option>15</option>
        <option>16</option>
        <option>17</option>
        <option>18</option>
        <option>19</option>
        <option>20</option>
        <option>21</option>
        <option>22</option>
        <option>23</option>
        <option>24</option>
        <option>25</option>
        <option>26</option>
        <option>27</option>
        <option>28</option>
        <option>29</option>
        <option>30</option>
        <option>31</option>
      </select>
/
<select name="em2" id="em2">
  <option value="" selected="selected">-</option>
  <option>1</option>
  <option>2</option>
  <option>3</option>
  <option>4</option>
  <option>5</option>
  <option>6</option>
  <option>7</option>
  <option>8</option>
  <option>9</option>
  <option>10</option>
  <option>11</option>
  <option>12</option>
</select>
/
<select name="ey2" id="ey2">
  <option value="" selected="selected">-</option>
  <option>2010</option>
  <option>2011</option>
  <option>2012</option>
  <option>2013</option>
  <option>2014</option>
  <option>2015</option>
  <option>2016</option>
  <option>2017</option>
</select> 
Time: 
<select name="ehh2" id="ehh2">
  <option value="" selected="selected">-</option>
  <option>00</option>
  <option>01</option>
  <option>02</option>
  <option>03</option>
  <option>04</option>
  <option>05</option>
  <option>06</option>
  <option>07</option>
  <option>08</option>
  <option>09</option>
  <option>10</option>
  <option>11</option>
  <option>12</option>
  <option>13</option>
  <option>14</option>
  <option>15</option>
  <option>16</option>
  <option>17</option>
  <option>18</option>
  <option>19</option>
  <option>20</option>
  <option>21</option>
  <option>22</option>
  <option>23</option>
 </select>
: 
<select name="emm2" id="emm2">
  <option value="" selected="selected">-</option>
  <option>00</option>
  <option>01</option>
  <option>02</option>
  <option>03</option>
  <option>04</option>
  <option>05</option>
  <option>06</option>
  <option>07</option>
  <option>08</option>
  <option>09</option>
  <option>10</option>
  <option>11</option>
  <option>12</option>
  <option>13</option>
  <option>14</option>
  <option>15</option>
  <option>16</option>
  <option>17</option>
  <option>18</option>
  <option>19</option>
  <option>20</option>
  <option>21</option>
  <option>22</option>
  <option>23</option>
  <option>24</option>
  <option>25</option>
  <option>26</option>
  <option>27</option>
  <option>28</option>
  <option>29</option>
  <option>30</option>
  <option>31</option>
  <option>32</option>
  <option>33</option>
  <option>34</option>
  <option>35</option>
  <option>36</option>
  <option>37</option>
  <option>38</option>
  <option>39</option>
  <option>40</option>
  <option>41</option>
  <option>42</option>
  <option>43</option>
  <option>44</option>
  <option>45</option>
  <option>46</option>
  <option>47</option>
  <option>48</option>
  <option>49</option>
  <option>50</option>
  <option>51</option>
  <option>52</option>
  <option>53</option>
  <option>54</option>
  <option>55</option>
  <option>56</option>
  <option>57</option>
  <option>58</option>
  <option>59</option>
 </select></td>
    </tr>
    <tr>
      <td>Registeration Due Date</td>
      <td>:</td>
      <td>Date :
        <select name="ed3" id="ed3">
          <option value="" selected="selected">-</option>
          <option>1</option>
          <option>2</option>
          <option>3</option>
          <option>4</option>
          <option>5</option>
          <option>6</option>
          <option>7</option>
          <option>8</option>
          <option>9</option>
          <option>10</option>
          <option>11</option>
          <option>12</option>
          <option>13</option>
          <option>14</option>
          <option>15</option>
          <option>16</option>
          <option>17</option>
          <option>18</option>
          <option>19</option>
          <option>20</option>
          <option>21</option>
          <option>22</option>
          <option>23</option>
          <option>24</option>
          <option>25</option>
          <option>26</option>
          <option>27</option>
          <option>28</option>
          <option>29</option>
          <option>30</option>
          <option>31</option>
        </select>
        /
        <select name="em3" id="em3">
          <option value="" selected="selected">-</option>
          <option>1</option>
          <option>2</option>
          <option>3</option>
          <option>4</option>
          <option>5</option>
          <option>6</option>
          <option>7</option>
          <option>8</option>
          <option>9</option>
          <option>10</option>
          <option>11</option>
          <option>12</option>
        </select>
        /
        <select name="ey3" id="ey3">
          <option value="" selected="selected">-</option>
          <option>2010</option>
          <option>2011</option>
          <option>2012</option>
          <option>2013</option>
          <option>2014</option>
          <option>2015</option>
          <option>2016</option>
          <option>2017</option>
        </select>
        Time:
        <select name="ehh3" id="ehh3">
          <option value="" selected="selected">-</option>
          <option>00</option>
          <option>01</option>
          <option>02</option>
          <option>03</option>
          <option>04</option>
          <option>05</option>
          <option>06</option>
          <option>07</option>
          <option>08</option>
          <option>09</option>
          <option>10</option>
          <option>11</option>
          <option>12</option>
          <option>13</option>
          <option>14</option>
          <option>15</option>
          <option>16</option>
          <option>17</option>
          <option>18</option>
          <option>19</option>
          <option>20</option>
          <option>21</option>
          <option>22</option>
          <option>23</option>
        </select>
        :
        <select name="emm3" id="emm3">
          <option value="" selected="selected">-</option>
          <option>00</option>
          <option>01</option>
          <option>02</option>
          <option>03</option>
          <option>04</option>
          <option>05</option>
          <option>06</option>
          <option>07</option>
          <option>08</option>
          <option>09</option>
          <option>10</option>
          <option>11</option>
          <option>12</option>
          <option>13</option>
          <option>14</option>
          <option>15</option>
          <option>16</option>
          <option>17</option>
          <option>18</option>
          <option>19</option>
          <option>20</option>
          <option>21</option>
          <option>22</option>
          <option>23</option>
          <option>24</option>
          <option>25</option>
          <option>26</option>
          <option>27</option>
          <option>28</option>
          <option>29</option>
          <option>30</option>
          <option>31</option>
          <option>32</option>
          <option>33</option>
          <option>34</option>
          <option>35</option>
          <option>36</option>
          <option>37</option>
          <option>38</option>
          <option>39</option>
          <option>40</option>
          <option>41</option>
          <option>42</option>
          <option>43</option>
          <option>44</option>
          <option>45</option>
          <option>46</option>
          <option>47</option>
          <option>48</option>
          <option>49</option>
          <option>50</option>
          <option>51</option>
          <option>52</option>
          <option>53</option>
          <option>54</option>
          <option>55</option>
          <option>56</option>
          <option>57</option>
          <option>58</option>
          <option>59</option>
      </select></td>
    </tr>
    <tr>
      <td width="40%">Organiser</td>
      <td width="2%">:</td>
      <td width="58%"><input name="eorg" type="text" id="eorg" size="50" /></td>
    </tr>
    <tr>
      <td>Banner</td>
      <td>:</td>
      <td><input type="file" name="ebanner" id="fileField" /></td>
    </tr>
    <tr>
      <td width="40%">Details</td>
      <td width="2%">&nbsp;</td>
      <td width="58%">&nbsp;</td>
    </tr>
    <tr>
      <td height="500" colspan="3" valign="top"><textarea name="edesc" id="edesc" cols="80" rows="30"></textarea></td>
    </tr>
    <tr>
      <td width="40%">&nbsp;</td>
      <td width="2%">&nbsp;</td>
      <td width="58%">&nbsp;</td>
    </tr>
    <tr>
      <td width="40%">Participant requirements:</td>
      <td width="2%">&nbsp;</td>
      <td width="58%">&nbsp;</td>
    </tr>
    <tr>
      <td>For UTeM Student</td>
      <td>&nbsp;</td>
      <td><select name="epartyes2" id="epartyes2">
        <option selected="selected">Enable</option>
        <option>Disable</option>
      </select></td>
    </tr>
    <tr>
      <td width="40%">For UTeM Staff</td>
      <td width="2%">&nbsp;</td>
      <td width="58%"><select name="epartyes" id="epartyes">
        <option selected="selected">Enable</option>
        <option>Disable</option>
      </select></td>
    </tr>
    <tr>
      
      <td colspan=3><p>* leave blank for optional/unlimited required</p>
        <table width="100%%" border="0" cellspacing="0" cellpadding="0">
          <tr>
            <td width="50%">PTJ</td>
            <td width="15%">Total of Staff</td>
            <td width="15%">Total of Required Staff </td>
            <td width="20%">Through and copy</td>
          </tr>
          <?php
		  	$num = 0;
		  	$query = mysql_query("SELECT * FROM OfficeCode");
			while ($row = mysql_fetch_array($query))
			{
				$num++;
		  ?>
          <tr>
            <td width="50%"><?php echo $row["OfficeName"]; ?></td>
            <?php
			$totalStaff = 0;
		  	$query2 = mysql_query("SELECT * FROM Office WHERE OfficeID=".$row["OfficeID"]);
			while ($row2 = mysql_fetch_array($query2))
			{
				$totalStaff++;
			}
			?>
            <td width="15%"><?php echo $totalStaff;?></td>
            <td width="15%"><input name="ename2" type="text" id="ename2" size="5" /></td>
            <td width="20%"><select name="epartno3" id="epartno3">
            <?php
		  	$query2 = mysql_query("SELECT * FROM Office WHERE OfficeID=".$row["OfficeID"]);
			while ($row2 = mysql_fetch_array($query2))
			{
				$query3 = mysql_query("SELECT * FROM Staff WHERE StaffID=".$row2["StaffID"]." LIMIT 0,1");
				$rowName = mysql_fetch_array($query3);
				?>
              <option value=<?php echo $rowName["StaffID"]; ?>><?php echo $rowName["Name"]; ?></option>
              <?php } ?>
              
              <option value=0>Others...</option>
            </select></td>
          </tr>
          <?php } ?>
        </table>
      <p>For Formal Letter No. 1, signed by: 
        <select name="epartno2" id="epartno2">
          <option>[Staff 1]</option>
          <option>[Staff 2]</option>
        </select>
      </p></td>
    </tr>
    <tr>
      <td width="40%">For Non-UTeM</td>
      <td width="2%">&nbsp;</td>
      <td width="58%"><select name="epartno" id="epartno">
        <option selected="selected">Enable</option>
        <option>Disable</option>
      </select></td>
    </tr>
    <tr>
      <td>Click here to view list all registered participants</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
      <td>&nbsp;</td>
    </tr>
    <tr>
      <td width="40%">&nbsp;</td>
      <td width="2%">&nbsp;</td>
      <td width="58%"><input type="submit" name="chk" id="chk" value="Save" />
      <input type="submit" name="xxx" id="xxx" value="Delete" /></td>
    </tr>
  </table>
</form>
