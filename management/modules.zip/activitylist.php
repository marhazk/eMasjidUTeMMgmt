<table width="100%%" border="0" cellspacing="0" cellpadding="0">
  <tr>
    <td width="80%"><strong>Activity Name</strong></td>
    <td width="20%">&nbsp;</td>
  </tr>
  <tr>
    <td width="80%"><strong>OCTOBER 2012</strong></td>
    <td width="20%"><img src="btn/add.png" width="23" height="24"></td>
  </tr>
  <tr>
    <td width="80%">Activity Name 1</td>
    <td width="20%"><img src="btn/del.png" width="23" height="24"><a href="?op=activityinfo"><img src="btn/enter.png" width="23" height="24"></a></td>
  </tr>
  <tr>
    <td width="80%">Activity Name 2</td>
    <td width="20%"><img src="btn/del.png" width="23" height="24"><a href="?op=activityinfo"><img src="btn/enter.png" width="23" height="24"></a></td>
  </tr>
  <tr>
    <td width="80%">Activity Name 3</td>
    <td width="20%"><img src="btn/del.png" width="23" height="24"><a href="?op=activityinfo"><img src="btn/enter.png" width="23" height="24"></a></td>
  </tr>
  <tr>
    <td width="80%"><strong>SEPTEMBER 2012</strong></td>
    <td width="20%"><img src="btn/add.png" width="23" height="24"></td>
  </tr>
  <tr>
    <td width="80%">Activity Name 1</td>
    <td width="20%"><img src="btn/del.png" width="23" height="24"><a href="?op=activityinfo"><img src="btn/enter.png" width="23" height="24"></a></td>
  </tr>
  <tr>
    <td width="80%">Activity Name 2</td>
    <td width="20%"><img src="btn/del.png" width="23" height="24"><a href="?op=activityinfo"><img src="btn/enter.png" width="23" height="24"></a></td>
  </tr>
  <tr>
    <td width="80%">Activity Name 3</td>
    <td width="20%"><img src="btn/del.png" width="23" height="24"><a href="?op=activityinfo"><img src="btn/enter.png" width="23" height="24"></a></td>
  </tr>
</table>
